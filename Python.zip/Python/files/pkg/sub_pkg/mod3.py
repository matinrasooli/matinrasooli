from .. import sub_pkg
print(sub_pkg)

from ..sub_pkg.mod1 import foo
foo()
