def sub_foo():
    print('[mod1.py] foo()')

class SubFoo:
    pass
