def multiply(a, b):
    return a * b

class Bar:
    pass
